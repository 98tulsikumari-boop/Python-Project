# Use list comprehensions to display employee salary data, such as - every employee is getting a 10% salary Hike.
# You must display: Employee Name, Current salary updated, salary after 10% Hike.
# ----------------------------------------------------------------------------------------------------------------
class Employee:
    def __init__(self, **kwargs):
        self.name = kwargs.get("name", "Unknown")
        self.salary = kwargs.get("salary", 0)

    def display_info(self):
        print(f"Name of Employee: {self.name},\nSalary: {self.salary} ")
        
# ----Main-------
if __name__ == "__main__":
    employee_list: list = []

    while True:
        print("\n1. Insert Employee's details")
        print("2. Display Details")
        print("3. Updated details")
        print("4. Exit the Program\n")

        ch: int = int(input("Enter your choice: "))

        if ch == 1:
            n: str = input("Enter Employee's name: ")
            s: int = int(input("Enter salary: "))

            employee = Employee(name=n, salary=s)
            employee_list.append(employee)

            print("\n Details added successfully.")

        elif ch == 2:
            if not employee_list:
                print("No Details to Show.")
            else: 
                print("--Details--")
                for emp in employee_list:
                    emp.display_info()

        elif ch == 3:
            if not employee_list:
                print("No Details to Show.")
            else: 
                print("--Updated Details--")

                # List Comprehension for Updated Salary
                updated_details = [
                    Employee(name=n, salary=int(s * 1.10)) for emp in employee_list
                ]

                for emp in updated_details:
                    emp.display_info()
        elif ch == 4:
            print("Exit the Program.")
            break
        else:
             print("Invalid Choice! Please choose valid choice.")
            
            
            
