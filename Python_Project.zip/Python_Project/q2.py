# Write a program to log all user activities using Python's logging module.
# ----------------------------------------------------------------------------

import logging

logging.basicConfig(
    filename = "activity.log",
    level = logging.INFO,
    format = "%(asctime)s - %(levelname)s - %(message)s"
)

def log_action(**kwargs):
    action = kwargs.get("action", "Unknown Action")
    logging.info(action)

# -----Main-----
if __name__ == "__main__":

    while True:
        print("\n1. User Login")
        print("2. User Opened Dashboard")
        print("3. User Logged Out")
        print("4. Exit Program\n")

        ch: int = int(input("Enter your Choice: "))

        if ch == 1:
            print("User Logged in Successfully!")
            log_action(action="User Logged in")

        elif ch == 2:
            print("User Opened Dashboard")
            log_action(action="User Viewed Dashboard")

        elif ch == 3:
            print("User Logged out!")
            log_action(action="User Logged out")

        elif ch == 4:
            print("Exit the Program\n")
            break
        else: 
            print("Invalid Choice! Please choose valid choice.")