from math_operations import add, subtract, multiply, divide, main
from io import StringIO
import sys

def test_add():
    assert add(15, 3) == 18

def test_subtract():
    assert subtract(15, 3) == 12

def test_multiply():
    assert multiply(15, 3) == 45

def test_divide():
    assert divide(15, 3) == 5

# Testing Program with user input
def test_main(monkeypatch, capsys):
    fake_input = StringIO("15\n3\n")
    monkeypatch.setattr(sys, "stdin", fake_input)

    main()

    output = capsys.readouterr().out
    assert "Addition = 18" in output
    assert "Subtract = 12" in output
    assert "Multiply = 45" in output
    assert "Division = 5.0" in output



