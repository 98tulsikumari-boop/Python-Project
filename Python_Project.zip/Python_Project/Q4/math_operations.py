# Build a unit test for a simple math function using pytest.
# -----------------------------------------------------------

def add(num1, num2):
    return num1 + num2

def subtract(num1, num2):
    return num1 - num2

def multiply(num1, num2):
    return num1 * num2

def divide(num1, num2):
    return num1 / num2

def main():
    num1: int = int(input("\nEnter First number: "))
    num2: int = int(input("Enter Second number: "))

    print("Addition =", add(num1, num2))
    print("Subtract =", subtract(num1, num2))
    print("Multiply =", multiply(num1, num2))
    print("Division =", divide(num1, num2))


if __name__ == "__main__":
    main()

