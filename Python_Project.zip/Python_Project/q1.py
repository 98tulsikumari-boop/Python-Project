# Mini Utility Project: Create a Command-line utility calculate student grades using dictionary and loops.
# ----------------------------------------------------------------------------------------------------------

class Student:
    def __init__(self, **kwargs):
        self.name = kwargs.get('name', 'Unknown')
        self.marks = int(kwargs.get('marks', 0))
        self.grade = self.calculate_grade(self.marks)

    def calculate_grade(self, marks):
        grade_chart = {
            "O": range(90, 101),
            "A+": range(75, 90),
            "A": range(60, 75),
            "B": range(45, 60),
            "C": range(35,45),
            "D": range(25, 35),
            "Fail": range(0, 25)
        }
        #  For loop to get grade
        for grade, marks_range in grade_chart.items():
            if marks in marks_range:
                return grade
            
        return "Invalid Marks"
         
    def display_info(self):
        print(f"Name: {self.name}, \nMarks: {self.marks},\nGrade: {self.grade}")

# ---------Main---------
if __name__ == "__main__":
    student_detail: list = []

    while True:
        print("\n1. Add Student Detail")
        print("2. Display Information")
        print("3. Exit the Program\n")

        ch: int = int(input("Enter your choice: "))

        if ch == 1:
            n: str = input("Enter Name of Student: ")
            m: str = input("Enter Marks of Student: ")

            student = Student(name=n, marks=m,)
            student_detail.append(student)
            print("\nStudent Details added Successfully.")

        elif ch == 2:
            if not student_detail:
                print("No Details to Display")
            else:
                print("---Student Details---")
                for s in student_detail:
                    s.display_info()

        elif ch == 3:
            print("Exit The Program")
            break
        else:
            print("Invalid Choice! Please choose valid choice.")
            
